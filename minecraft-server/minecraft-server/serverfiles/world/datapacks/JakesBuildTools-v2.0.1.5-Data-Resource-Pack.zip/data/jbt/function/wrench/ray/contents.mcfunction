execute store result score $item_count jbt_block_found_check run data get block ~ ~ ~ Items
execute if score $item_count jbt_block_found_check matches 0 run return 1
return fail