#work around for https://bugs.mojang.com/browse/MC-273361
execute if dimension minecraft:the_end in minecraft:the_nether run return run tp @s -20000000 10000 98
execute in minecraft:the_end run return run tp @s -20000000 10000 98